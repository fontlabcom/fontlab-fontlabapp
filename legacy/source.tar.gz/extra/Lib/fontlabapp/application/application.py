#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright (c) 2022 Adam Twardoch
# License: BSD 3-Clause License
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import fontlab

try:
    from .paths import ApplicationPaths
    from .versions import Versions
    from ..utils import to_html, to_pre
except ImportError:
    from fontlabapp.paths import ApplicationPaths
    from fontlabapp.versions import Versions
    from fontlabapp.utils import to_html, to_pre
from PythonQt import QtGui


class Application(object):
    def __init__(self, with_ui=True, with_preflib=True):
        self.ws = fontlab.flWorkspace.instance()
        self.main = self.ws.mainWindow
        self.qmenus = self.main.menuBar()
        self.item = fontlab.flItems
        self.qapp = QtGui.QApplication.instance()
        self.pref = fontlab.flPreferences()
        self.paths = ApplicationPaths(self)
        self.versions = Versions(self)
        if with_preflib:
            from .preflib import PrefLib

            self.preflib = PrefLib(self)
        if with_ui:
            from .ui import ApplicationUI

            self.ui = ApplicationUI(self)

    def debug(self, msg, md=False, styled=False, css=""):
        if md:
            msg = to_html(msg, md=True, styled=styled, css=css)
        elif styled:
            msg = to_html(msg, md=False, styled=styled, css=css)
        else:
            msg += "\n"
        self.main.doOutput(msg, False)

    def info(self, msg, gui=False, md=False, styled=False, css=""):
        if md:
            msg = to_html(msg, md=True, styled=styled, css=css)
        elif styled:
            msg = to_html(msg, md=False, styled=styled, css=css)
        else:
            msg += "\n"
        if gui:
            QtGui.QMessageBox(QtGui.QMessageBox.Information, "Info", msg).exec()
        else:
            self.main.doOutput(msg, True)

    def warn(self, msg, gui=False, md=False, styled=False, css=""):
        if md:
            msg = to_html(msg, md=True, styled=styled, css=css)
        elif styled:
            msg = to_html(msg, md=False, styled=styled, css=css)
        else:
            msg += "\n"
        if gui:
            QtGui.QMessageBox(QtGui.QMessageBox.Warning, "Warning", msg).exec()
        else:
            self.main.doWarning(msg)

    def error(self, msg, gui=False, md=False, styled=False, css=""):
        if gui:
            if md:
                msg = to_html(msg, md=True, styled=styled, css=css)
            elif styled:
                msg = to_html(msg, md=False, styled=styled, css=css)
            QtGui.QMessageBox(QtGui.QMessageBox.Critical, "Error", msg).exec()
        else:
            if md:
                msg = to_html(
                    f"""<small>[ERROR] </small>\n{msg}""",
                    md=True,
                    styled=styled,
                    css=f"""color:lightcoral;{css}""",
                )
            elif styled:
                msg = to_html(
                    msg, md=False, styled=styled, css=f"""color:lightcoral;{css}"""
                )
            else:
                msg = f"[ERROR] {msg}\n"
            self.main.doWarning(msg)

    def print(self, msg):
        self.debug(to_pre(msg))

    def print_md(self, msg, styled=False, css=""):
        self.debug(to_html(msg, md=True, styled=styled, css=css))

    def print_html(self, msg, styled=False, css=""):
        self.debug(to_html(msg, md=False, styled=styled, css=css))
