#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
if sys.platform == "darwin":
    from .mac import HotkeyManager
elif sys.platform == "win32":
    raise NotImplementedError
